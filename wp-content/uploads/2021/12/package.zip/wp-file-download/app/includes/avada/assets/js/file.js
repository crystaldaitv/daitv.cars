jQuery(document).ready(function ($) {

    if ( !$('.fusion-builder-live').length && $('.wpfd-avada-single-file > link').length ) {
        $('.wpfd-avada-single-file > link').remove();
    }

});