jQuery(document).ready(function ($) {

    if ( !$('.fusion-builder-live').length && $('.wpfd-avada-category > link').length ) {
        $('.wpfd-avada-category > link').remove();
    }

});