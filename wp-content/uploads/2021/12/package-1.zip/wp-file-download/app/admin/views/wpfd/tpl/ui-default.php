<?php
/**
 * WP File Download
 *
 * @package WP File Download
 * @author  Joomunited
 * @version 1.0W
 */

use Joomunited\WPFramework\v1_0_5\Utilities;
use Joomunited\WPFramework\v1_0_5\Application;

// No direct access.
defined('ABSPATH') || die();

if (!wpfd_can_manage_file()) {
    wp_die(esc_html__('You don\'t have permission to view this page', 'wpfd'));
}

wp_localize_script('wpfd-main', 'l10n', array(
    'Drag & Drop your Document here'                   => esc_html__('Drag & Drop your Document here', 'wpfd'),
    'Add remote file'                                  => esc_html__('Add remote file', 'wpfd'),
    'Allowed extensions'                               => esc_html__('Allowed extensions', 'wpfd'),
    'SEO URL'                                          => esc_html__('SEO URL', 'wpfd'),
    'Show files import'                                => esc_html__('Show files import', 'wpfd'),
    'Max upload file size (Mb)'                        => esc_html__('Max upload file size (Mb)', 'wpfd'),
    'Delete all files on uninstall'                    => esc_html__('Delete all files on uninstall', 'wpfd'),
    'Close categories'                                 => esc_html__('Close categories', 'wpfd'),
    'Theme per categories'                             => esc_html__('Theme per categories', 'wpfd'),
    'Default theme per category'                       => esc_html__('Default theme per category', 'wpfd'),
    'Date format'                                      => esc_html__('Date format', 'wpfd'),
    'Use viewer'                                       => esc_html__('Use viewer', 'wpfd'),
    'Extensions to open with viewer'                   => esc_html__('Extensions to open with viewer', 'wpfd'),
    'GA download tracking'                             => esc_html__('GA download tracking', 'wpfd'),
    'Single user restriction'                          => esc_html__('Single user restriction', 'wpfd'),
    'Use WYSIWYG editor'                               => esc_html__('Use WYSIWYG editor', 'wpfd'),
    'Load the plugin on frontend'                      => esc_html__('Load the plugin on frontend', 'wpfd'),
    'Category owner'                                   => esc_html__('Category owner', 'wpfd'),
    'Search page'                                      => esc_html__('Search page', 'wpfd'),
    'Plain text search'                                => esc_html__('Plain text search', 'wpfd'),
    'Are you sure'                                     => esc_html__('Are you sure', 'wpfd'),
    'Delete'                                           => esc_html__('Delete', 'wpfd'),
    'Edit'                                             => esc_html__('Edit', 'wpfd'),
    'Your browser does not support HTML5 file uploads' => esc_html__('Your browser does not support HTML5 file uploads!', 'wpfd'),
    'Too many files'                                   => esc_html__('Too many files', 'wpfd'),
    'is too large'                                     => esc_html__('is too large', 'wpfd'),
    'Only images are allowed'                          => esc_html__('Only images are allowed', 'wpfd'),
    'Do you want to delete'                            => esc_html__('Do you want to delete', 'wpfd'),
    'Select files'                                     => esc_html__('Select files', 'wpfd'),
    'Image parameters'                                 => esc_html__('Image parameters', 'wpfd'),
    'Cancel'                                           => esc_html__('Cancel', 'wpfd'),
    'Ok'                                               => esc_html__('Ok', 'wpfd'),
    'Confirm'                                          => esc_html__('Confirm', 'wpfd'),
    'Save'                                             => esc_html__('Save', 'wpfd'),
    'Title'                                            => esc_html__('Title', 'wpfd'),
    'Remote URL'                                       => esc_html__('Remote URL', 'wpfd'),
    'URL'                                              => esc_html__('URL', 'wpfd'),
    'File Type'                                        => esc_html__('File Type', 'wpfd'),
    'close_categories'                                 => WpfdBase::loadValue($this->globalConfig, 'close_categories', 0),
    'add_remote_file'                                  => WpfdBase::loadValue($this->globalConfig, 'add_remote_file', 0),
    'Are you sure restore file'                        => esc_html__('Are you sure you want to restore the file: ', 'wpfd'),
    'Are you sure remove version'                      => esc_html__('Are you sure you want to definitively remove this file version', 'wpfd'),
    'Deleting...'                                      => esc_html__('Deleting...', 'wpfd'),
    'Please select file(s)'                            => esc_html__('Please select file(s)', 'wpfd'),
    'There is no copied/cut files yet'                 => esc_html__('There is no copied/cut files yet', 'wpfd'),
    'This type of file is not allowed to be uploaded. You can add new file types in the plugin configuration' => esc_html__('This type of file is not allowed to be uploaded. You can add new file types in the plugin configuration', 'wpfd'),

    'uploaded successfully'                           => esc_html__('uploaded successfully', 'wpfd'),
    'error while uploading'                           => esc_html__('error while uploading', 'wpfd'),
    'files imported'                                  => esc_html__('files imported', 'wpfd'),
    'Are you sure to disconnect'                      => esc_html__('Are you sure to disconnect', 'wpfd'),
    'Checking Authorization Code....'                 => esc_html__('Checking Authorization Code....', 'wpfd'),
    'Something wrong! Check Console Tab for details.' => esc_html__('Something wrong! Check Console Tab for details.', 'wpfd'),
    'Success! Page will reload now...'                => esc_html__('Success! Page will reload now...', 'wpfd'),
    'Pending...'                                      => esc_html__('Pending...', 'wpfd')
));

if (Utilities::getInput('caninsert', 'GET', 'bool')) {
    global $hook_suffix;
    _wp_admin_html_begin();
    do_action('admin_enqueue_scripts', $hook_suffix);
    do_action('admin_print_scripts-' . $hook_suffix);
    do_action('admin_print_scripts');
    if ((is_plugin_active('polylang/polylang.php') && class_exists('Polylang')) ||
        (is_plugin_active('wp-fastest-cache/wpFastestCache.php') && class_exists('WpFastestCache'))
    ) {
        echo '<script type="text/javascript">
           var ajaxurl = "' . esc_url(admin_url('admin-ajax.php')) . '";
         </script>';
    }
}

$alone = '';
?>
<script type="text/javascript">
    wpfdajaxurl = "<?php echo wpfd_sanitize_ajax_url(Application::getInstance('Wpfd')->getAjaxUrl()); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- keep this, if not it error on backend?>";
    // Fix conflict with WPML
    if (wpfdajaxurl.substr(-1, 1) !== '&') {
        wpfdajaxurl = wpfdajaxurl + '&';
    }
    dir = "<?php echo esc_url(Application::getInstance('Wpfd')->getBaseUrl()); ?>";
    <?php if (Utilities::getInput('caninsert', 'GET', 'bool')) : ?>
    gcaninsert = true;
        <?php $alone = 'wpfdalone wp-core-ui '; ?>
    <?php else : ?>
    gcaninsert = false;
    <?php endif; ?>
    if (typeof(addLoadEvent) === 'undefined') {
        addLoadEvent = function (func) {
            if (typeof jQuery !== "undefined") {
                jQuery(document).ready(func);
            }
            else if (typeof wpOnload !== 'function') {
                wpOnload = func;
            } else {
                var oldonload = wpOnload;
                wpOnload = function () {
                    oldonload();
                    func();
                }
            }
        };
    }
</script>
<?php if (Utilities::getInput('caninsert', 'GET', 'bool')) : ?>
    <style>
        html.wp-toolbar {
            padding-top: 0 !important
        }
    </style>
<?php endif;
/**
 * Action to write import notice
 */
do_action('wpdf_admin_notices');
?>
<?php include 'ui-contextmenu.php'; ?>
<div id="wpfd-core" class="<?php echo esc_attr($alone); ?>">
    <div id="wpfd-categories-col" class="wpfd-column">
        <?php if (wpfd_can_create_category()) :
            $class = '';
            $isCloud = wpfd_is_cloud_exists();
            if ($isCloud) {
                $class = 'hasCloud';
            }
            ?>
            <div id="newcategory" class="ju-dropdown-wrapper <?php echo $isCloud ? 'hasCloud' : ''; ?>">
                <a class="ju-button ju-v3-button wpfd_add_new" href="#">
                    <i class="material-icons">add</i>
                    <?php esc_html_e('Add Category', 'wpfd'); ?>
                </a>
                <ul class="ju-dropdown-menu">
                    <?php
                    /**
                     * Action fire for display Dropdown
                     *
                     * @internal
                     */
                    do_action('wpfd_addon_dropdown');
                    ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php include 'ui-categories-filter.php'; ?>
        <div class="wpfd-pseudo-top-cat">
            <svg xmlns="http://www.w3.org/2000/svg" width="26px" height="26px" viewBox="0 0 920 832">
                <path fill="#0073ab"
                      d="M955 7901 c-105 -18 -244 -135 -305 -255 l-35 -70 -8 -225 c-4 -124 -7 -1515 -5 -3091 l3 -2865 39 -73 c53 -100 136 -181 233 -229 l77 -38 3249 -3 3249 -2 71 37 c86 46 174 125 209 190 15 26 38 93 52 148 30 121 551 2923 715 3845 118 666 116 643 56 769 -69 144 -182 230 -351 269 l-79 18 -6 289 c-5 268 -7 294 -27 346 -48 120 -134 214 -248 270 l-65 32 -242 8 c-133 4 -1102 8 -2153 8 l-1911 1 -65 88 c-35 48 -93 130 -128 182 -138 207 -222 299 -307 338 -35 16 -115 17 -1008 19 -533 0 -988 -2 -1010 -6z m1838 -308 l67 -6 63 -86 c35 -47 104 -144 153 -215 107 -156 168 -224 247 -278 l59 -40 2152 -7 c1957 -6 2154 -8 2181 -23 80 -43 89 -79 89 -373 l1 -240 -3020 -5 -3020 -5 -80 -42 c-150 -77 -217 -158 -255 -310 -25 -97 -111 -537 -230 -1178 -228 -1225 -259 -1388 -271 -1400 -5 -5 -9 791 -9 2052 l0 2061 50 45 c28 25 61 48 73 50 36 7 1676 7 1750 0z m5431 -1634 c20 -22 41 -52 47 -66 12 -31 -6 -133 -270 -1568 -399 -2167 -536 -2892 -553 -2912 -20 -25 -93 -35 -322 -43 -304 -12 -5529 -12 -5846 0 -135 5 -262 14 -283 20 -44 13 -67 53 -67 118 0 34 68 430 145 847 14 77 42 226 61 330 187 1018 495 2642 583 3079 33 166 38 181 64 200 28 21 31 21 1205 26 647 3 2082 7 3188 8 l2012 2 36 -41z"
                      transform="matrix(.1 0 0 -.1 0 832)"/>
            </svg>
            <span class="wpfd-pseudo-label"><?php esc_html_e('WP File Download', 'wpfd'); ?></span>
        </div>
        <!-- display button connect to cloud -->
        <div class="scroller_wrapper_inner">
            <?php if (!wpfd_can_create_category() && empty($this->categories)) : ?>
                <?php esc_html_e('Sorry, your user role does not have access to any files category', 'wpfd'); ?>
            <?php endif; ?>

            <?php if (!empty($this->categories)) : ?>
                <div class="nested dd">
                    <ol id="categorieslist" class="dd-list nav bs-docs-sidenav2">
                        <?php
                        $content = '';
                        $previouslevel = 1;
                        // phpcs:ignore PHPCompatibility.FunctionUse.NewFunctions.is_countableFound -- is_countable() was declared in functions.php
                        $categories = is_countable($this->categories) ? count($this->categories) : 0;
                        $dropbox_connected = wpfd_dropbox_connected();
                        $google_connected = wpfd_google_drive_connected();
                        $onedrive_connected = wpfd_onedrive_connected();
                        $onedrive_business_connected = wpfd_onedrive_business_connected();
                        for ($index = 0; $index < $categories; $index++) {
                            $cloudType = isset($this->categories[$index]->cloudType) ? $this->categories[$index]->cloudType : false;

                            if (($cloudType === 'dropbox' && !$dropbox_connected) ||
                            ($cloudType === 'googleDrive' && !$google_connected) ||
                            ($cloudType === 'onedrive' && !$onedrive_connected) ||
                            ($cloudType === 'onedrive_business' && !$onedrive_business_connected)
                            ) {
                                continue;
                            }
                            if ($index + 1 !== $categories) {
                                $nextlevel = (int) $this->categories[$index + 1]->level;
                            } else {
                                $nextlevel = 0;
                            }
                            $content .= openItem($this->categories[$index], $index, $this->globalConfig);
                            if ($nextlevel > $this->categories[$index]->level) {
                                $content .= openlist($this->categories[$index]);
                            } elseif ($nextlevel === (int) $this->categories[$index]->level) {
                                $content .= closeItem();
                            } else {
                                $c       = '';
                                $c       .= closeItem();
                                $c       .= closeList();
                                $content .= str_repeat($c, $this->categories[$index]->level - $nextlevel);
                            }
                            $previouslevel = (int) $this->categories[$index]->level;
                        }

                        echo $content; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside functions
                        ?>
                </ol>
                <input type="hidden" id="categoryToken" name=""/>
            </div>
            <?php endif; ?>
        </div>
            <div id="wpfd-hamburger">
                <a href="javascript: void();" class="dashicons dashicons-leftright"></a>
                <span><?php esc_html_e('Categories', 'wpfd'); ?></span>
            </div>
    </div>

    <div id="pwrapper" class="wpfd-column">
        <div id="wpreview">
            <div class="preview-top">
            <?php include 'ui-search.php'; ?>
            <?php include 'ui-insert-buttons.php'; ?>
            </div>
            <?php
            $class = (wpfd_can_edit_category() || wpfd_can_edit_own_category()) ? 'has-wpfd' : 'no-wpfd';
            ?>
            <div class="wpfd_center">
                <div id="preview" class="<?php echo esc_attr($class); ?>">
                </div>
            </div>
        </div>
        <?php if (wpfd_can_edit_category() || wpfd_can_edit_own_category() || Utilities::getInput('caninsert', 'GET', 'bool')) { ?>
            <div id="rightcol" class="wpfd-column">
                <?php if (wpfd_can_edit_category() || wpfd_can_edit_own_category()) { ?>
                    <div class="categoryblock">
                        <div class="well">
                            <!--                        <h4>--><?php //esc_html_e('Parameters', 'wpfd'); ?><!--</h4>-->
                            <div id="galleryparams">
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
        <?php } ?>
        <input type="hidden" name="id_category" value=""/>
    </div>


    <div id="wpfd_status">
        <div class="wpfd_status_header">
            <span class="header_title"><?php esc_html_e('File upload status', 'wpfd'); ?></span>
            <span class="toolbox minimize"></span>
        </div>
        <div class="wpfd_status_body">
        </div>
        <div class="wpfd_status_footer"></div>
    </div>
    <div id="wpfd_ios_category_menu">
        <svg xmlns="http://www.w3.org/2000/svg" height="30px" viewBox="0 0 24 24" width="30px" fill="#fff"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/></svg>
    </div>
    <div id="wpfd_ios_file_menu">
        <svg xmlns="http://www.w3.org/2000/svg" height="30px" viewBox="0 0 24 24" width="30px" fill="#fff"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M8 16h8v2H8zm0-4h8v2H8zm6-10H6c-1.1 0-2 .9-2 2v16c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zm4 18H6V4h7v5h5v11z"/></svg>
    </div>
</div>
<?php
/**
 * Open Item
 *
 * @param object  $category     Category
 * @param integer $key          Key
 * @param array   $globalConfig Config
 *
 * @return string
 */
function openItem($category, $key, $globalConfig)
{
    $iconsClass = '';
    $iconText = '';
    $type = $category->cloudType;
    switch ($type) {
        case 'dropbox':
            $iconsClass = 'dropbox-icon wpfd-folder wpfd-liga';
            $iconText = 'dropbox';
            break;
        case 'googleDrive':
            $iconsClass = 'google-drive-icon wpfd-folder wpfd-liga';
            $iconText = 'google_drive';
            break;
        case 'onedrive':
            $iconsClass = 'onedrive-icon wpfd-folder wpfd-liga';
            $iconText = 'onedrive';
            break;
        case 'onedrive_business':
            $iconsClass = 'onedrive-business-icon wpfd-folder wpfd-liga business';
            $iconText = 'onedrive';
            break;
    }

    if ($iconsClass === '') {
        $iconsClass = 'material-icons wpfd-folder';
        $iconText = 'folder';
    }

    $iconsCat = '<i';

    if ($category->color) {
        $iconsCat .= ' style="color: ' . $category->color . '"';
    }
    $iconsCat .= ' class="' . $iconsClass . '">' . $iconText . '</i>';

    if (isset($category->disable) && $category->disable) {
        $item_id_disable = 'data-item-disable="' . esc_attr($category->term_id) . '"';
        $dd_handle       = '';
        $category_count  = '';
        $disable         = ' disabled ';
    } else {
        $disable         = ' not_disable ';
        $item_id_disable = '';
        $dd_handle       = ' dd-handle ';
        $category_count  = $category->count;
    }

    $spacing = 10;
    if ($category->level > 0) {
        $padding = $spacing * ($category->level);
    }
    $item = '<li class="' . $disable . ' dd-item dd3-item ' . ($key ? '' : 'active') . '"';
    if (isset($padding) && $padding > 0) {
        $item .= ' style="padding-left: '.$padding.'px"';
    }
    $item .= ' data-color="' . esc_attr($category->color) . '"';
    $item .= ' data-parent-id="' . $category->parent . '"';
    $item .= ' data-id="' . $category->term_id . '" data-id-category="';
    $item .= $category->term_id . '"  ' . $item_id_disable . ' data-level="'.$category->level.'" data-type="'. $type . '">
        <div class="' . $disable . $dd_handle . ' dd3-handle">' . $iconsCat . '</div>';
    $margin = '';
    if (isset($padding) && $padding > 0) {
        $margin = ' style="margin-left: -' . ($padding + 20) . 'px;padding-left: '. ($padding + 67) .'px"';
    }
    $item .= '<div class="dd-content dd3-content' . $disable . $dd_handle . '" '.$margin.'>';
    if ((int) WpfdBase::loadValue($globalConfig, 'file_count', 0) !== 0 && $category_count !== null) {
        $item .= '<span class="countfile"><span class="count_badge">' . esc_html($category_count) . '</span></span>';
    }
    $item .= '<a href="" title="' . esc_html($category->name) . '" class="t' . $disable . '"' . $disable . '>';
    $item .= '<span class="title">' . esc_html($category->name);
    $item .= '</span> </a> </div>';

    return $item;
}

/**
 * Close Item
 *
 * @return string
 */
function closeItem()
{
    return '</li>';
}

/**
 * Content Item
 *
 * @param object $category Category
 *
 * @return string
 */
function itemContent($category)
{
    if (isset($category->disable) && $category->disable) {
        $disable   = ' disabled ';
        $dd_handle = '';
    } else {
        $disable   = '';
        $dd_handle = ' dd-handle ';
    }
    $item = '<div class="' . $disable . $dd_handle . ' dd3-handle">
                <i class="material-icons wpfd-folder">folder</i>
             </div>
             <div class="dd-content dd3-content"
             <i class="icon-chevron-right"></i>';
    if (wpfd_can_edit_category() || wpfd_can_edit_own_category()) {
        $item .= '<a class="edit"><i class="icon-edit"></i></a>';
    }
    $item .= '<a href="" class="t"> <span class="title">' . esc_html($category->name) . '</span> </a>
            </div>';

    return $item;
}

/**
 * Open List
 *
 * @param WP_Term $category Category object
 *
 * @return string
 */
function openlist($category = null)
{
    if (!is_null($category) && $category->level > 0) {
        $margin = ($category->level) * 10;
    }
    $html = '<ol class="dd-list"';
    if (isset($margin) && $margin > 0) {
        $html .= ' style="margin-left: -'.$margin.'px"';
    }
    $html .= '>';

    return $html;
}

/**
 * Close List
 *
 * @return string
 */
function closelist()
{
    return '</ol>';
}

?>
