<?php
/**
 * WP File Download
 *
 * @package WP File Download
 * @author  Joomunited
 * @version 1.0
 */

// No direct access.
defined('ABSPATH') || die();
?>

<h3 class="wpfd_no_file"><?php esc_html_e('No file found!', 'wpfd'); ?></h3>
